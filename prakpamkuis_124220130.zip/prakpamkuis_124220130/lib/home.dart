import 'package:flutter/material.dart';
import 'package:prakpamkuis_124220130/daftar_barang_dummy.dart';

class listbarang extends StatelessWidget {
  const listbarang({super.key, required this.username});
  final String username;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List Barang'),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2
        ),
        itemCount: supermarketItemList.length, //cuma nampilin sebanyak data ga ngelooping sebanyak2nya
        itemBuilder: (context, index){
          SupermarketItem market = supermarketItemList[index];
          return Card(
            child: Column(
              children: [
                Image.network(
                  market.imageUrls[0],
                  width: 300,
                  height: 250,
                  fit: BoxFit.fill
                  ),
                Text(market.name),
                Text(market.price),
              ],
            ),
          );
        }
        ),
    );
  }
}

