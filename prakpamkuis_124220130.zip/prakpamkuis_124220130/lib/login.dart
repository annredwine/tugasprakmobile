import 'package:flutter/material.dart';
import 'package:prakpamkuis_124220130/home.dart';

// statefulwidget itu buat ngubah apapun secara otomatis
class Login extends StatefulWidget {
  Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String Username = '';
  String Password = '';
  bool isLoginSuccess = true;
  bool visible = true;

  // bikin fungsi navigator biar pas tombol login nya di klik bisa pindah ke halaman lainnya
  _navigatePage() async { //async ini bikin ke hold
    await Future.delayed(Duration(seconds: 2)); //ini buat munculin snackbarnya dluan sebelum masuk ke halaman selanjutnya
    Navigator.push(context, MaterialPageRoute(builder: (context) {
      return listbarang(
        // data yang akan di passing ke home
        username: Username
      );
    }
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(appBar: AppBar(
        title: Text('Login Page'),
      ) ,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Image.asset('../assets/upnLogo.png'),
          // bikin widget uname sm pass
          _usernameField(), 
          _passwordField(),
          _loginButton(context),
        ],
      ),
      ));
  }

  Widget _usernameField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      // ini bikin textbox buat uname sm pass nya
      child: TextFormField(
        // bikin biar apa yg diketik di uname sm pass ke simpen di variable
        onChanged: (value){
          // apa yg diketik nnti akan masuk ke variable value
          Username = value;
        },
        enabled : true,
        decoration: InputDecoration(
          labelText: 'Username',
          // ini bikin kotakan textboxnya
          enabledBorder: OutlineInputBorder(
            // bikin kelengkungan dr si kotakannya
            borderRadius: BorderRadius.circular(10), 
            // bikin garis biar warnanya ga item doang
            borderSide: BorderSide(color: Colors.red),
            ),
        ),  
      ),
    );
  }

  Widget _passwordField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      // ini bikin textbox buat uname sm pass nya
      child: TextFormField(
        onChanged: (value){
          // apa yg diketik nnti akan masuk ke variable value
          Password = value;
        },
        // untuk bikin pass itu bisa diliat
        obscureText: visible,
        decoration: InputDecoration(
          suffixIcon: IconButton(
            onPressed: (){
              setState(() {
                visible = !visible;
              });
            },
            icon: Icon(visible ? Icons.visibility : Icons.visibility_off)),
          labelText: 'Password',
          // ini bikin kotakan textboxnya
          enabledBorder: OutlineInputBorder(
            // bikin kelengkungan dr si kotakannya
            borderRadius: BorderRadius.circular(10), 
            // bikin garis biar warnanya ga item doang
            borderSide: BorderSide(color: Colors.red),
            ),
        ),  
      ),
    );
  }

  Widget _loginButton(BuildContext context){
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        onPressed: (){
          String text = '';
          if (Username == 'admin' && Password == 'admin'){
            _navigatePage(); // manggil si navigator tadi
            setState(() {
              text = 'Login Berhasil';
              isLoginSuccess = true;
            });
          } else {
            setState(() {
              text = 'Login Gagal';
              isLoginSuccess = false;
            });
          }
          // buat nampilin yg pop up yg bagian bawahnya
          SnackBar snackBar = SnackBar(
            backgroundColor: isLoginSuccess ? Colors.blue : Colors.red,
            content: Text(text),
            duration: Duration(seconds: 3),
            );
          // pop up pemberitahuan berhasil/gagal
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }, 
        child: Text('Login')),
    );
  }
}