package com.example.prakpamkuis_124220130

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
