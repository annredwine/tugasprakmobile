package com.example.online

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
