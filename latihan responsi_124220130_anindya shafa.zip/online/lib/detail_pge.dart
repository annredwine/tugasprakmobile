import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:online/itemdetail_page.dart';

class DetailPage extends StatelessWidget {
  final String title;

  DetailPage({required this.title});

  Future<List<dynamic>> fetchData() async {
    String url = '';
    if (title == 'News') {
      url = 'https://api.spaceflightnewsapi.net/v4/articles/';
    } else if (title == 'Blog') {
      url = 'https://api.spaceflightnewsapi.net/v4/blogs/';
    } else if (title == 'Report') {
      url = 'https://api.spaceflightnewsapi.net/v4/reports/';
    }

    try {
      final response = await http.get(Uri.parse(url));

      // Periksa status kode dari respons API
      if (response.statusCode == 200) {
        // Memeriksa apakah respons valid sebagai JSON
        try {
          return json.decode(response.body)['results'];
        } catch (e) {
          throw FormatException('Failed to parse JSON');
        }
      } else {
        throw Exception('Failed to load data, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 111, 10, 10),
        centerTitle: true,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: fetchData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            var data = snapshot.data!;
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                var item = data[index];
                return ListTile(
                  title: Text(item['title'] ?? 'No title'),
                  subtitle: Text(item['summary'] ?? 'No summary available'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ItemDetailPage(
                          title: item['title'],
                          id: item['id'],
                        ),
                      ),
                    );
                  },
                );
              },
            );
          } else {
            return Center(child: Text('No data available.'));
          }
        },
      ),
    );
  }
}