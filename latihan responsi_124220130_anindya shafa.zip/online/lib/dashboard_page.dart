import 'package:flutter/material.dart';
import 'package:online/detail_pge.dart';
import 'package:online/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late SharedPreferences loginData;
  late String username; //buat nampung data username

  @override
  void initState() {
    super.initState();
    initial();
  }

  void initial() async{
    loginData = await SharedPreferences.getInstance();
    setState(() {
      username = loginData.getString('username')!; //tanda seru artinya null chek
    });
  }

  // Fungsi untuk logout
  Future<void> logout(BuildContext context) async {
    SharedPreferences loginData = await SharedPreferences.getInstance();
    // Setel status login menjadi false
    loginData.setBool('key', false);
    
    // Navigasi ke halaman login
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => HomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Hai! $username",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        centerTitle: true, // Memastikan teks berada di tengah
        ),
        
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children:[
                  MenuCard(
                    icon: Icons.newspaper,
                    title: 'News',
                    description: 'Get an overview of the latest SpaceFlight news, from various sources! Easily link your users to the right websites.',
                    onTap: () => navigateToDetail(context, 'News'),
                  ),

                  MenuCard(
                    icon: Icons.article,
                    title: 'Blog',
                    description: 'Blogs often provide a more detailed overview of launches and missions. A must-have for the serious spaceflight enthusiast.',
                    onTap: () => navigateToDetail(context, 'Blog'),
                  ),

                  MenuCard(
                    icon: Icons.report,
                    title: 'Report',
                    description: 'Space stations and other missions often publish their data. With SNAPi, you can include it in your reports.',
                    onTap: () => navigateToDetail(context, 'Report'),
                  ),
                ],
              )
        ),
      );
  }
}

void navigateToDetail(BuildContext context, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => DetailPage(title: title)),
    );
}

// Widget MenuCard untuk menampilkan menu dalam bentuk gambar dan teks
class MenuCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final VoidCallback onTap;

  MenuCard({
    required this.title,
    required this.description,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                leading: Icon(icon, size: 40, color: Color.fromARGB(255, 111, 10, 10)),
                title: Text(title, style: TextStyle(fontSize: 20)),
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  description,
                  style: TextStyle(fontSize: 14, color: Colors.black),
                ),
              ),
            ],
          ),
        )
      );
  }
}

