import 'package:flutter/material.dart';


class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Warna latar belakang
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Colors.teal, // Warna AppBar lebih menarik
        elevation: 5, // Shadow pada AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Dekorasi untuk kotak informasi kelompok
            Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const Text(
                'Halo^^ \nNama saya Anindya Shafa Rizkia \nNIM saya 124220130 \nSaya masih belajar, mohon maaf jika tampilan belum bagus dan rapi',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal, // Warna teks
                ),
                textAlign: TextAlign.center, // Teks berada di tengah
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}