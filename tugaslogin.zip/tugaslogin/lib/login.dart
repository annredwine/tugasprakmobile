import 'package:flutter/material.dart';
import 'home.dart';

// statefulwidget itu buat ngubah apapun secara otomatis
class Login extends StatefulWidget {
  Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String Username = '';

  String Password = '';
  bool isLoginSuccess = true;
  bool visible = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(appBar: AppBar(
        title: Text('Login Page'),
      ) ,
      body: Column(
        children: [
          // bikin widget uname sm pass
          _usernameField(), 
          _passwordField(),
          _loginButton(context),
        ],
      ),
      ));
  }

  Widget _usernameField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      // ini bikin textbox buat uname sm pass nya
      child: TextFormField(
        // bikin biar apa yg diketik di uname sm pass ke simpen di variable
        onChanged: (value){
          // apa yg diketik nnti akan masuk ke variable value
          Username = value;
        },
        enabled : true,
        decoration: InputDecoration(
          labelText: 'Username',
          // ini bikin kotakan textboxnya
          enabledBorder: OutlineInputBorder(
            // bikin kelengkungan dr si kotakannya
            borderRadius: BorderRadius.circular(10), 
            // bikin garis biar warnanya ga item doang
            borderSide: BorderSide(color: Colors.red),
            ),
        ),  
      ),
    );
  }

  Widget _passwordField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      // ini bikin textbox buat uname sm pass nya
      child: TextFormField(
        onChanged: (value){
          // apa yg diketik nnti akan masuk ke variable value
          Password = value;
        },
        // untuk bikin pass itu bisa diliat
        obscureText: visible,
        decoration: InputDecoration(
          suffixIcon: IconButton(
            onPressed: (){
              setState(() {
                visible = !visible;
              });
            },
            icon: Icon(visible ? Icons.visibility : Icons.visibility_off)),
          labelText: 'Password',
          // ini bikin kotakan textboxnya
          enabledBorder: OutlineInputBorder(
            // bikin kelengkungan dr si kotakannya
            borderRadius: BorderRadius.circular(10), 
            // bikin garis biar warnanya ga item doang
            borderSide: BorderSide(color: Colors.red),
            ),
        ),  
      ),
    );
  }

  Widget _loginButton(BuildContext context){
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        onPressed: (){
          String text = '';
          if (Username == 'gojo' && Password == '444'){
            setState(() {
              text = 'Login Berhasil';
              isLoginSuccess = true;
            });
          } else {
            setState(() {
              text = 'Login Gagal';
              isLoginSuccess = false;
            });
          }
          // buat nampilin yg pop up yg bagian bawahnya
          SnackBar snackBar = SnackBar(
            backgroundColor: isLoginSuccess ? Colors.green : Colors.red,
            content: Text(text),
            duration: Duration(seconds: 3),
            );
          // pop up pemberitahuan berhasil/gagal
          ScaffoldMessenger.of(context).showSnackBar(snackBar);

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const Home()),
          );
        }, 
        child: Text('Login')),
    );
  }
}