import 'package:flutter/material.dart';
import 'package:res/detail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:res/main.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late SharedPreferences loginData;
  late String username; //buat nampung data username

  @override
  void initState() {
    super.initState();
    initial();
  }

  void initial() async{
    loginData = await SharedPreferences.getInstance();
    setState(() {
      username = loginData.getString('username')!; //tanda seru artinya null chek
    });
  }

  // Fungsi untuk logout
  Future<void> logout(BuildContext context) async {
    SharedPreferences loginData = await SharedPreferences.getInstance();
    // Setel status login menjadi false
    loginData.setBool('key', false);
    
    // Navigasi ke halaman login
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => HomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Hai! $username",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 185, 38, 38),
        centerTitle: true, // Memastikan teks berada di tengah
        ),
        
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children:[
                  MenuCard(
                    imageData: Image.asset('assets/image/gudeg.jpg'), 
                    title: 'Beef',
                    description: 
                      'Beef is the culinary name for meat from cattle, particularly skeletal muscle.',
                    onTap: () => navigateToDetail(context, 'Beef'),
                  ),

                  MenuCard(
                    //icon: Icons.article,
                    imageData: Image.asset('assets/image/gudeg.jpg'),
                    title: 'Chicken',
                    description: 
                      'Beef is the culinary name for meat from cattle, particularly skeletal muscle.',
                    onTap: () => navigateToDetail(context, 'Beef'),
                  ),

                  MenuCard(
                    //icon: Icons.article,
                    imageData: Image.asset('assets/image/gudeg.jpg'),
                    title: 'Dessert',
                    description: 
                      'Beef is the culinary name for meat from cattle, particularly skeletal muscle.',
                    onTap: () => navigateToDetail(context, 'Beef'),
                  ),
                ],
              )
        ),
      );
  }
}

void navigateToDetail(BuildContext context, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => DetailPage(title: title)),
    );
}

// Widget MenuCard untuk menampilkan menu dalam bentuk gambar dan teks
class MenuCard extends StatelessWidget {
  final String title;
  final String description;
  final VoidCallback onTap;
  //final IconData icon;
  final Image imageData;

  MenuCard({
    required this.imageData,
    //required this.icon,
    required this.title,
    required this.description,    
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
          child: Column(
            //crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center, // Memastikan form dan tombol di tengah vertikal
            crossAxisAlignment: CrossAxisAlignment.center, // Agar elemen-elemen berada di tengah horizontal
            children: [
              Image.asset(
                'assets/image/gudeg.jpg',
                width: 50,
                height: 50,
              ),

              ListTile(
                //leading: Icon(icon, size: 40, color: Color.fromARGB(255, 111, 10, 10)),
                title: Text(title, style: TextStyle(fontSize: 20)),
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  description,
                  style: TextStyle(fontSize: 14, color: Colors.black),
                ),
              ),
            ],
          ),
        )
      );
  }
}

