import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ItemDetailPage extends StatelessWidget {
  final String title;
  final String id;

  ItemDetailPage({required this.title, required this.id});

  Future<Map<String, dynamic>> fetchDetailData() async {
    //final url = 'https://api.spaceflightnewsapi.net/v4/$title/$id/';
    final url = 'https://www.themealdb.com/api/json/v1/1/lookup.php?i=$id';

    try {
      final response = await http.get(Uri.parse(url));

      // Periksa status kode dari respons API
      if (response.statusCode == 200) {
        try {
          return json.decode(response.body);
        } catch (e) {
          throw FormatException('Failed to parse JSON');
        }
      } else {
        throw Exception('Failed to load detail data, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching detail data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.black,
        centerTitle: true,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchDetailData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            var data = snapshot.data!;
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data['title'] ?? 'No Title',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    data['summary'] ?? 'No Summary Available',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Content:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    data['content'] ?? 'No Content Available',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            );
          } else {
            return Center(child: Text('No data available.'));
          }
        },
      ),
    );
  }
}