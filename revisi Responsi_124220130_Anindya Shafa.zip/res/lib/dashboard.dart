import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:res/detail.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late SharedPreferences loginData;
  late String username; // Untuk menyimpan data username
  List categories = []; // Deklarasi untuk menyimpan data kategori makanan

  @override
  void initState() {
    super.initState();
    initial();
    fetchCategories(); // Memuat data kategori saat halaman dimuat
  }

  void initial() async {
    loginData = await SharedPreferences.getInstance();
    setState(() {
      username = loginData.getString('username') ?? 'Guest'; // Null check
    });
  }

  Future<void> fetchCategories() async {
    const url = 'https://www.themealdb.com/api/json/v1/1/categories.php';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        setState(() {
          categories = json.decode(response.body)['categories'];
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat kategori')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Terjadi kesalahan: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Hai! $username",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 185, 38, 38),
        centerTitle: true, // Memastikan teks berada di tengah
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: categories.isEmpty
            ? Center(child: CircularProgressIndicator()) // Menampilkan loading
            : ListView.builder(
                itemCount: categories.length,
                itemBuilder: (context, index) {
                  final category = categories[index];
                  return MenuCard(
                    imageData: Image.network(category['strCategoryThumb']),
                    title: category['strCategory'],
                    description: category['strCategoryDescription'],
                    onTap: () => navigateToDetail(context, category['strCategory']),
                  );
                },
              ),
      ),
    );
  }
}

void navigateToDetail(BuildContext context, String title) {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => DetailPage(title: title)),
  );
}

// Widget MenuCard untuk menampilkan menu dalam bentuk gambar dan teks
class MenuCard extends StatelessWidget {
  final String title;
  final String description;
  final VoidCallback onTap;
  final Image imageData;

  MenuCard({
    required this.imageData,
    required this.title,
    required this.description,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              child: imageData,
            ),
            ListTile(
              title: Text(title, style: TextStyle(fontSize: 30)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                description,
                style: TextStyle(fontSize: 14, color: Colors.black),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
