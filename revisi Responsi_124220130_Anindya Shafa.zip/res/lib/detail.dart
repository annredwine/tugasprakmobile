import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:res/itemdetail_page.dart';

class DetailPage extends StatelessWidget {
  final String title;

  DetailPage({required this.title});

  Future<List<dynamic>> fetchData() async {
    // Menentukan URL berdasarkan kategori
    String url = 'https://www.themealdb.com/api/json/v1/1/filter.php?c=$title';

    try {
      final response = await http.get(Uri.parse(url));

      // Periksa status kode dari respons API
      if (response.statusCode == 200) {
        // Parsing respons JSON untuk mendapatkan daftar makanan
        final data = json.decode(response.body);
        return data['meals']; // Daftar makanan sesuai respons API
      } else {
        throw Exception('Failed to load data, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 111, 10, 10),
        centerTitle: true,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: fetchData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            var meals = snapshot.data!;
            return GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Jumlah kolom dalam grid
                crossAxisSpacing: 10, // Jarak horizontal antar item
                mainAxisSpacing: 10, // Jarak vertikal antar item
              ),
              itemCount: meals.length,
              itemBuilder: (context, index) {
                var meal = meals[index];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ItemDetailPage(
                          title: meal['strMeal'],
                          id: meal['idMeal'],
                        ),
                      ),
                    );
                  },
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 5,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(10),
                          ),
                          child: Image.network(
                            meal['strMealThumb'],
                            width: double.infinity,
                            height: 120,
                            fit: BoxFit.contain, // Pastikan gambar tidak terpotong
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            meal['strMeal'],
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ); 
          } else {
            return Center(child: Text('No data available.'));
          }
        },
      ),
    );
  }
}
