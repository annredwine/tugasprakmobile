import 'package:flutter/material.dart';
import 'package:res/dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.white),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final username_controller = TextEditingController();
  final password_controller = TextEditingController();

  //definisiin login data yang mau diambil
  late SharedPreferences loginData;
  late bool newUser;

  @override
  void initState() {
    // untuk inisialisasi awal
    super.initState();
    check_login(); //panggil fungsi cek login tadi
  }

  //bikin fungsi buat ngecek user udah pernah login atau belum
  void check_login() async{
    //ambil intens dr sharereferense yg udh dibuat tadi
    loginData = await SharedPreferences.getInstance();
    newUser = (loginData.getBool('login') ?? true); //cara bacanya : ada engga key dr login klo gada kembaliinnya true
    if (newUser == false){
      Navigator.pushReplacement(
        context, new MaterialPageRoute(builder: (context) => DashboardPage()) //akan kelempar ke halaman dashboard
      );
    }
  }

  @override
  void dispose() {
    // dispose ini untuk ngeclear dr controller biar ga boros memori
    username_controller.dispose();
    password_controller.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Login Page",
          style: TextStyle(color: Colors.white), // Mengubah warna teks menjadi putih
        ),
        backgroundColor: Color.fromARGB(255, 185, 38, 38), // Warna latar belakang appBar
        centerTitle: true, // Memastikan teks berada di tengah
      ),

      body: Center(
        child: SingleChildScrollView( // Untuk mencegah form terpotong saat keyboard muncul
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center, // Memastikan form dan tombol di tengah vertikal
              crossAxisAlignment: CrossAxisAlignment.center, // Agar elemen-elemen berada di tengah horizontal
              children: <Widget>[
                
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: TextField(
                    controller: username_controller,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Username',
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: TextField(
                    controller: password_controller,
                    obscureText: true, // Agar password tidak terlihat
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Password',
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: ElevatedButton(
                    onPressed: () {
                      String username = username_controller.text; // Menangkap username
                      String password = password_controller.text; // Menangkap password

                      if (username != "" && password != "") { // Pastikan tidak kosong
                        loginData.setBool('login', false);
                        loginData.setString('username', username); // Menyimpan username
                        Navigator.push(
                          context, 
                          MaterialPageRoute(builder: (context) => DashboardPage())
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color.fromARGB(255, 111, 10, 10), // Warna marron (hex: #6F4F37)
                      padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    ),
                    child: Text(
                      "Login",
                      style: TextStyle(color: Colors.white), // Warna teks putih
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      )

    );
  }
}
