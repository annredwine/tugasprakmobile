import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

class ItemDetailPage extends StatelessWidget {
  final String title;
  final String id;

  ItemDetailPage({required this.title, required this.id});

  Future<Map<String, dynamic>> fetchDetailData() async {
    final url = 'https://www.themealdb.com/api/json/v1/1/lookup.php?i=$id';

    try {
      final response = await http.get(Uri.parse(url));

      // Periksa status kode dari respons API
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['meals'][0]; // Mengambil detail pertama dari daftar
      } else {
        throw Exception('Failed to load detail data, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching detail data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 111, 10, 10),
        centerTitle: true,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchDetailData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            var meal = snapshot.data!;
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Gambar Makanan
                  Center(
                    child: Image.network(
                      meal['strMealThumb'],
                      width: 300,
                      height: 200,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 16),
                  // Nama Makanan
                  Text(
                    meal['strMeal'],
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  // Kategori dan Asal
                  Text(
                    'Category: ${meal['strCategory']}',
                    style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic),
                  ),
                  Text(
                    'Origin: ${meal['strArea']}',
                    style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic),
                  ),
                  SizedBox(height: 16),
                  // Bahan-Bahan
                  Text(
                    'Ingredients:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  for (int i = 1; i <= 20; i++)
                    if (meal['strIngredient$i'] != null &&
                        meal['strIngredient$i'].isNotEmpty)
                      Text(
                        '${meal['strIngredient$i']} - ${meal['strMeasure$i']}',
                        style: TextStyle(fontSize: 16),
                      ),
                  SizedBox(height: 16),
                  // Instruksi Memasak
                  Text(
                    'Instructions:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    meal['strInstructions'],
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 16),
                  // Tombol Video Tutorial
                  if (meal['strYoutube'] != null &&
                      meal['strYoutube'].isNotEmpty)
                    Center(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 111, 10, 10), // Warna marron (hex: #6F4F37)
                        padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                      ),
                      child: Text(
                        "Watch Tutorial",
                        style: TextStyle(color: Colors.white), // Warna teks putih
                      ),
                        onPressed: () {
                          _launchURL(meal['strYoutube']);
                        },
                      ),
                    ),
                ],
              ),
            );
          } else {
            return Center(child: Text('No data available.'));
          }
        },
      ),
    );
  }

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
