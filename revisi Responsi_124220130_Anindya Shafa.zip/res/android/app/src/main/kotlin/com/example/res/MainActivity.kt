package com.example.res

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
